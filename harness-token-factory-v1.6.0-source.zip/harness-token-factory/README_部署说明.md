# Harness Platform & Token Factory · 完整部署包

版本：1.6.0 · 打包日期：2026-10-19

完整的中文架构互动学习网站，包含五层架构、31 个模块、51 条直接关联的用途与条件说明，以及协同模拟、知识目录、资料链接和学习进度。最新的“点击组件查看关联”功能已包含在本包中。

## v1.6.0 最终交互规则

**悬停只看关联，点击才看说明。** 鼠标移到组件上，只高亮直接关联的组件与连线；移开后恢复原选中组件和连线筛选。不显示悬停解释浮层，不自动打开说明弹窗，也不自动展开弹窗内的关联说明。点击组件才打开完整说明，弹窗内的关联条目也需要点击展开；触屏仍通过点按查看。

## 完整架构展示

架构图恢复为主页面完整展开的五层布局，没有图内滚动条、固定高度或缩放窗口，也无需再点“展开全貌”。窄屏按区域和资源池重新排布，使用浏览器页面正常浏览。点击任何组件均打开说明弹窗，功能、原理、关联关系、边界与资料均在弹窗内查看；关闭后保留原页面浏览位置。长篇说明可在弹窗正文内滚动，标题与标签保持可见。

更新时完整替换 `dist/` 目录并重新加载页面，确保 HTML、JS、CSS 属于同一版本。

## 最快上线方式

**把 `dist/` 里的全部文件及 `assets/` 子目录上传到静态网站托管服务或 Web 服务器的网站根目录。入口是 `index.html`，不需要构建，不需要安装 Node.js，也不需要后端、数据库或模型 API Key。**

在有“构建命令 / 发布目录”的平台上，构建命令留空，发布目录填写 `dist`。如果平台要求上传网站文件，则上传 `dist` 内的内容。不要把本部署包的文档、测试和参考材料一起作为网站根目录公开。

主站使用 ES modules，请通过 HTTP/HTTPS 访问；双击文件查看请使用 `offline/` 内的单文件版本。

## 包内目录

| 路径 | 内容 |
| --- | --- |
| `dist/` | 可直接部署的网站，同时也是可编辑源码 |
| `offline/` | 已内嵌脚本和样式的单文件 HTML，可双击查看 |
| `reference-diagrams/` | 原有两版参考架构 PNG 及调整、连线说明；无需上传至站点 |
| `deployment/` | Nginx 配置、Dockerfile、Docker Compose 配置 |
| `tests/` | 模拟逻辑、关联关系、页面及离线版检查脚本 |
| `preview.mjs` | 本地静态预览服务器 |
| `bundle-offline.mjs` | 从当前 `dist` 重新生成离线文件 |
| `README_开发说明.md` | 内容维护与技术建模说明 |
| `VALIDATION.md` | 本次验证结果与未验证项 |
| `SHA256SUMS.txt` | 包内文件的 SHA-256 校验清单 |

## 方式一：现有 Nginx 服务器

1. 将 `dist/` 内容复制到服务器网站目录，例如 `/usr/share/nginx/html/`；先备份已有站点，避免覆盖其他网站。
2. 将 `deployment/nginx.conf` 作为独立站点配置使用，按实际环境修改 `root`、`server_name` 和监听端口。已有主站时，把配置并入对应站点，避免重复监听配置。
3. 使用 `nginx -t` 验证配置，通过后重载 Nginx。
4. 由现有反向代理或托管平台绑定域名并启用 HTTPS。

JavaScript 应以 JavaScript MIME 类型返回，CSS 应以 `text/css` 返回。标准 Nginx 的 `mime.types` 已覆盖这些类型。页面使用 `#architecture`、`#simulation` 等 hash 导航，无需额外的 SPA 路由回退。

## 方式二：Docker Compose

进入解压后的 `Harness-Token-Factory` 目录，执行：

```sh
docker compose -f deployment/compose.yaml up -d --build
```

在该服务器本机访问 `http://127.0.0.1:8080`。默认只监听回环地址，适合接入已有的 HTTPS 反向代理；对外访问由反向代理转发至 `127.0.0.1:8080`。按实际域名及访问策略完成代理配置后即可上线。

更新文件后，再执行同一命令即可重新构建并启动。停止：

```sh
docker compose -f deployment/compose.yaml down
```

也可以手动构建：

```sh
docker build -f deployment/Dockerfile -t harness-token-factory:1.6.0 .
docker run -d --name infra-lab -p 127.0.0.1:8080:80 harness-token-factory:1.6.0
```

Docker 镜像需要从镜像仓库拉取，受部署环境网络和 Docker 配置影响；本次未执行镜像拉取或容器上线。

## 本地预览与修改

开发脚本需要 Node.js 20.11 或以上版本；静态部署不需要 Node.js。

```sh
node preview.mjs
```

访问 `http://127.0.0.1:4173`，用 Ctrl+C 停止。预览服务器只供本地使用。

- 修改模块、关系说明及官方资料链接：`dist/content.js`。
- 修改界面交互、关系高亮及详情展示：`dist/app.js`。
- 修改模拟逻辑与示例流程：`dist/simulation.js`。
- 修改样式：`dist/styles.css`；修改页面结构：`dist/index.html`。
- 维护图中连线时使用同一份 `relations` 数据；详情、直接关联组件与连线据此生成。

重新生成离线版：

```sh
node bundle-offline.mjs
```

结果写入 `offline/Harness_Platform_Token_Factory_互动学习应用.html`。

## 检查方法

内容与模拟逻辑检查不需要安装任何依赖：

```sh
npm test
```

可选的浏览器检查需要联网安装 Playwright 和 Chromium：

```sh
npm install --no-save playwright
npx playwright install chromium
```

执行 `npm run test:browser` 检查包内离线版及完整布局；该脚本默认无需启动服务器。如需检查 HTTP 部署版，先运行 `node preview.mjs`，并将环境变量 `SITE_TEST_URL` 设置为 `http://127.0.0.1:4173` 再运行脚本。离线版与边界检查分别执行 `npm run test:offline` 和 `npm run test:quality`。输出写入 `.qa/`。如需使用已有 Chromium，可设置环境变量 `PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH` 为浏览器可执行文件路径。

本次打包已完成的检查及限制见 `VALIDATION.md`，浏览器脚本随包提供不代表本次已运行。

## 数据、访问与部署验收

网站没有登录系统，也没有调用模型、工具或真实集群。模拟内容是内置教学示例；学习进度只保存在访问者当前浏览器的 localStorage。静态文件不引用 CDN 字体或第三方脚本，点击官方资料链接时会打开外部网站。

**原私有 Sites 的访问控制不会随静态文件迁移。若新站仍限内部使用，请在新托管平台或反向代理上设置登录、访问名单或其他既有认证方式。**

上线后请确认：悬停仅高亮关系，没有解释浮层或自动展开；点击才显示解释说明；五层架构完整展开，图内无独立滚动条；31 个模块均可点击打开说明弹窗，底部组件的解释也在可视区；关闭弹窗回到原位置；切换关系时连线与组件高亮相应变化；协同模拟可播放与单步运行；手机页面可使用；更新后浏览器没有加载旧版 JS/CSS。本包默认使用 no-cache 响应头便于重新验证资源。

本包不包含原有托管平台的项目身份、Git 仓库、发布凭据、运行日志或个人机器路径；可独立部署。参考架构图为静态历史材料，交互网站中的 31 个模块与 51 条关系以 `dist/content.js` 为准。
