import {mkdir as prepareQa} from 'node:fs/promises';
await prepareQa('.qa',{recursive:true});
import {chromium} from 'playwright';
import fs from 'node:fs/promises';import path from 'node:path';import assert from 'node:assert/strict';import {pathToFileURL} from 'node:url';
import {modules,relationsFor} from '../dist/content.js';
await fs.mkdir('.qa',{recursive:true});
const browser=await chromium.launch({headless:true,...(process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH?{executablePath:process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH}:{})});
const url=process.env.SITE_TEST_URL||pathToFileURL(path.resolve('offline/Harness_Platform_Token_Factory_互动学习应用.html')).href;
const errors=[],results=[],p=await browser.newPage({viewport:{width:1440,height:1000}});p.on('pageerror',e=>errors.push(e.message));
async function check(name,fn){try{await fn();results.push({name,passed:true});console.log('PASS',name);}catch(e){results.push({name,passed:false,error:e.message});console.error('FAIL',name,e.stack);}}
async function close(page){await page.keyboard.press('Escape');await page.waitForFunction(()=>!document.querySelector('#module-dialog').open);}
await p.goto(url);
await check('Architecture has all five layers and no nested scrolling viewport',async()=>{
 assert.equal(await p.locator('#architecture-map .node').count(),31);assert.equal(await p.locator('#inspector,#architecture-overview,#map-scroll').count(),0);
 assert.ok(await p.locator('#map-canvas').evaluate(el=>!['auto','scroll','hidden'].includes(getComputedStyle(el).overflowY)&&el.scrollHeight<=el.clientHeight+1&&el.scrollWidth<=el.clientWidth+1));
 await p.screenshot({path:'.qa/full-architecture-desktop.png',fullPage:true});
});
await check('Mouse hover only highlights associations; explanations stay closed until click',async()=>{
 await p.locator('[data-edge="management"]').click();const before=p.url();await p.locator('#architecture-map [data-module="nimcache"]').hover();
 await p.waitForFunction(()=>document.querySelector('#architecture-map').classList.contains('is-previewing'));assert.equal(await p.locator('#module-dialog').evaluate(el=>el.open),false);assert.equal(p.url(),before);
 assert.equal(await p.locator('#relation-hover').count(),0);assert.equal(await p.locator('#map-wires [data-relation-line]').count(),relationsFor('nimcache').length);assert.equal(await p.locator('#architecture-map .preview-source').getAttribute('data-module'),'nimcache');
 await p.screenshot({path:'.qa/hover-lines-only.png',fullPage:false});await p.mouse.move(2,2);await p.waitForFunction(()=>!document.querySelector('#architecture-map').classList.contains('is-previewing'));assert.equal(await p.locator('[data-edge="management"]').getAttribute('aria-pressed'),'true');
});
await check('All 31 components open complete popup explanations with five accessible tabs',async()=>{
 for(const m of modules){await p.locator(`#architecture-map [data-module="${m.id}"]`).click();assert.ok(await p.locator('#module-dialog').evaluate(el=>el.open));assert.equal(await p.locator('#dialog-title').textContent(),m.title);for(const tab of ['overview','principle','relations','boundary','sources']){await p.locator(`#detail-dialog-${tab}`).click();assert.ok((await p.locator('#panel-dialog').textContent()).length>30);}await close(p);assert.equal(await p.evaluate(()=>document.activeElement?.dataset.module),m.id);}
});
await check('A bottom component opens visible explanations and closing keeps the original page position',async()=>{
 const node=p.locator('#architecture-map [data-module="hardware"]');await node.scrollIntoViewIfNeeded();const y=await p.evaluate(()=>scrollY);await node.click();
 assert.ok(await p.locator('#dialog-title').evaluate(el=>{const r=el.getBoundingClientRect();return r.top>=0&&r.bottom<=innerHeight;}));assert.ok(Math.abs(await p.evaluate(()=>scrollY)-y)<2);
 assert.equal(await p.locator('#module-dialog [data-relationship]').count(),relationsFor('hardware').length);await p.screenshot({path:'.qa/full-map-bottom-popup.png',fullPage:false});await close(p);assert.ok(Math.abs(await p.evaluate(()=>scrollY)-y)<2);
});
await check('Relationships expose purpose, conditions and connected component navigation',async()=>{
 await p.locator('#architecture-map [data-module="nimcache"]').click();assert.equal(await p.locator('#module-dialog [data-relationship]').count(),relationsFor('nimcache').length);assert.match(await p.locator('.relationship-body:not([hidden])').textContent(),/适用条件与边界/);
 const next=await p.locator('.relationship-body:not([hidden]) [data-module]').first().getAttribute('data-module');await p.locator('.relationship-body:not([hidden]) [data-module]').first().click();assert.equal(await p.locator('#dialog-title').textContent(),modules.find(m=>m.id===next).title);await close(p);
});
await check('Relationship explanation entries require click, and do not expand on hover',async()=>{
 await p.locator('#architecture-map [data-module="nimcache"]').click();const button=p.locator('#module-dialog [data-relation]').nth(1);assert.equal(await button.getAttribute('aria-expanded'),'false');await button.hover();assert.equal(await button.getAttribute('aria-expanded'),'false');await button.click();assert.equal(await button.getAttribute('aria-expanded'),'true');assert.ok(await button.locator('..').locator('.relationship-body').isVisible());await close(p);
});
await check('Request and management filters remain available on the full diagram',async()=>{
 await p.locator('[data-edge="request"]').click();assert.equal(await p.locator('#map-wires .management').count(),0);assert.ok(await p.locator('#map-wires .request').count()>0);await p.locator('[data-edge="management"]').click();assert.equal(await p.locator('#map-wires .request').count(),0);assert.ok(await p.locator('#map-wires .management').count()>0);await p.locator('[data-edge="all"]').click();
});
await check('Keyboard opens module popup and knowledge tabs support Home, End and arrows',async()=>{
 await p.locator('#architecture-map [data-module="openshell"]').focus();await p.keyboard.press('Enter');await p.locator('#detail-dialog-overview').focus();await p.keyboard.press('ArrowRight');assert.equal(await p.locator('#detail-dialog-principle').getAttribute('aria-selected'),'true');await p.keyboard.press('End');assert.equal(await p.locator('#detail-dialog-sources').getAttribute('aria-selected'),'true');await p.keyboard.press('Home');assert.equal(await p.locator('#detail-dialog-overview').getAttribute('aria-selected'),'true');await close(p);
});
await check('Knowledge search, full reading and learning progress work with popup-only explanations',async()=>{
 await p.locator('nav [data-view="library"]').click();assert.equal(await p.locator('.knowledge-card').count(),31);await p.locator('#library-search').fill('NIMCache');assert.ok(await p.locator('.knowledge-card').count()>0);await p.locator('#library-search').fill('');await p.locator('.knowledge-card[data-module="nimcache"]').click();await p.locator('#module-dialog [data-learn]').click();assert.match(await p.locator('#module-dialog [data-learn]').textContent(),/已理解/);await close(p);
});
async function finish(){let n=0;while(await p.locator('#sim-step').isEnabled()){await p.locator('#sim-step').click();assert.ok(n++<40);}}
await p.locator('nav [data-view="simulation"]').click();
await check('Agent loop, security rejection and quota wait preserve their behavior',async()=>{
 await p.locator('[data-scenario="contract"]').click();await finish();assert.equal(await p.locator('#metric-requests').textContent(),'2');assert.equal(await p.locator('#metric-tools').textContent(),'2');assert.equal(await p.locator('#metric-chunks').textContent(),'8');
 await p.locator('[data-scenario="blocked"]').click();await finish();assert.equal(await p.locator('#metric-requests').textContent(),'0');assert.match(await p.locator('#run-status').textContent(),/已拒绝/);
 await p.locator('[data-scenario="provision"]').click();await p.locator('#quota').selectOption('wait');await finish();assert.match(await p.locator('#run-status').textContent(),/等待配额/);assert.equal(await p.locator('#event-log li').count(),3);
});
const mobile=await browser.newPage({viewport:{width:390,height:844},hasTouch:true,isMobile:true});mobile.on('pageerror',e=>errors.push(e.message));await mobile.goto(url);
await check('Phone and tablet reflow all modules without horizontal diagram scrollbars',async()=>{
 for(const width of [390,820]){await mobile.setViewportSize({width,height:844});assert.equal(await mobile.locator('#architecture-map .node').count(),31);assert.ok(await mobile.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1));assert.ok(await mobile.locator('#map-canvas').evaluate(el=>el.scrollWidth<=el.clientWidth+1&&el.scrollHeight<=el.clientHeight+1));await mobile.locator('#architecture-map [data-module="hardware"]').tap();assert.match(await mobile.locator('#dialog-title').textContent(),/基础设施/);await close(mobile);}
});
await check('No JavaScript errors',async()=>assert.deepEqual(errors,[]));
await fs.writeFile('.qa/browser-results.json',JSON.stringify({results,errors},null,2));await browser.close();if(results.some(r=>!r.passed))process.exitCode=1;
