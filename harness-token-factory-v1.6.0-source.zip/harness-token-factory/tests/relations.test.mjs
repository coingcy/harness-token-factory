import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {modules,moduleMap,owners,sources,relations,relationsFor,relationTypes} from '../dist/content.js';

test('Every module has explained, sourced direct relationships without duplicate edges',()=>{
 const ids=new Set(),pairs=new Set();
 for(const r of relations){assert.ok(moduleMap[r.from]&&moduleMap[r.to]);assert.notEqual(r.from,r.to);assert.ok(relationTypes[r.type]);assert.ok(r.label.length>3&&r.purpose.length>20&&r.condition.length>20);assert.ok(r.refs.length);for(const ref of r.refs)assert.ok(sources[ref]);assert.ok(!ids.has(r.id));ids.add(r.id);const pair=`${r.from}:${r.to}`;assert.ok(!pairs.has(pair));pairs.add(pair);}
 for(const m of modules){const links=relationsFor(m.id);assert.ok(links.length>0,m.id);const expected=[...new Set(links.map(r=>r.from===m.id?r.to:r.from))];assert.deepEqual(m.related,expected);}
});
test('Management controllers do not appear as per-request proxies; engines are alternatives',()=>{
 for(const r of relations.filter(r=>['nimoperator','kueue','gpuoperator','networkoperator','hami','nvsflow'].includes(r.from)||['nimoperator','kueue','gpuoperator','networkoperator','hami','nvsflow'].includes(r.to)))assert.notEqual(r.type,'request');
 const engineEdges=relations.filter(r=>r.from==='dynamo'&&['trtllm','vllm','sglang'].includes(r.to));assert.equal(engineEdges.length,3);assert.ok(engineEdges.every(r=>r.condition.includes('后端选项之一')));
 assert.equal(relations.filter(r=>['trtllm','vllm','sglang'].includes(r.from)&&['trtllm','vllm','sglang'].includes(r.to)).length,0);
});
const app=fs.readFileSync(new URL('../dist/app.js',import.meta.url),'utf8');
const excerpt=app.slice(app.indexOf('function relationContent('),app.indexOf('function renderInspector('));
const state={learned:new Set(),detailTab:'relations',activeRelation:null};
const ctx=vm.createContext({state,moduleMap,owners,sources,relationsFor,relationTypes,esc:v=>String(v).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;'),icon:()=>'',moduleIcon:()=>''});
vm.runInContext(excerpt,ctx);
test('All 31 relation panels render full purposes, conditions, and valid accessible targets',()=>{
 for(const m of modules){ctx.m=m;const html=vm.runInContext('moduleDetail(m)',ctx),links=relationsFor(m.id);assert.equal((html.match(/data-relationship=/g)||[]).length,links.length);for(const r of links){assert.ok(html.includes(r.purpose));assert.ok(html.includes(r.condition));assert.ok(html.includes(`id="relation-inspector-${r.id}"`));assert.ok(html.includes(`aria-controls="relation-inspector-${r.id}"`));}assert.equal((html.match(/aria-expanded="true"/g)||[]).length,1);}
});
test('Inbound direction, explicit selection, collapse, and dialog IDs remain consistent',()=>{
 ctx.m=moduleMap.nimcache;const incoming=relationsFor('nimcache').find(r=>r.from==='nimoperator');state.activeRelation=incoming.id;let html=vm.runInContext('moduleDetail(m,true)',ctx);assert.ok(html.includes('← NIM Operator'));assert.ok(html.includes(`aria-controls="relation-dialog-${incoming.id}"`));assert.equal((html.match(/aria-expanded="true"/g)||[]).length,1);state.activeRelation='none';html=vm.runInContext('moduleDetail(m)',ctx);assert.equal((html.match(/aria-expanded="true"/g)||[]).length,0);state.activeRelation=null;
});
