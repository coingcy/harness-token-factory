import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import vm from 'node:vm';
import {modules,moduleMap} from '../dist/content.js';
const app=fs.readFileSync(new URL('../dist/app.js',import.meta.url),'utf8');
const code=app.slice(app.indexOf('function showHoverPreview('),app.indexOf('function relationContent('));
function rig(){const state={view:'architecture',selected:'harness',edgeMode:'management',activeRelation:'saved',hovered:null},dialog={open:false};let draws=0;const c=vm.createContext({state,moduleMap,$:()=>dialog,drawMap:()=>draws++});vm.runInContext(code,c);return{state,dialog,c,draws:()=>draws};}
test('Hovering all 31 components only updates graph highlighting and never opens explanations',()=>{
 const r=rig();for(const m of modules){vm.runInContext(`showHoverPreview('${m.id}')`,r.c);assert.equal(r.state.hovered,m.id);assert.equal(r.state.selected,'harness');assert.equal(r.state.edgeMode,'management');assert.equal(r.state.activeRelation,'saved');}assert.equal(r.draws(),31);
 // There is no document, modal opener or content renderer in the context.
});
test('Moving within one component does not redraw; leaving restores the original selection and filter',()=>{
 const r=rig();vm.runInContext("showHoverPreview('nimcache');showHoverPreview('nimcache');hideHoverPreview()",r.c);assert.equal(r.draws(),2);assert.equal(r.state.hovered,null);assert.equal(r.state.selected,'harness');assert.equal(r.state.edgeMode,'management');
});
test('Invalid modules, other pages and open dialogs cannot trigger background hover highlights',()=>{
 const r=rig();vm.runInContext("showHoverPreview('__proto__')",r.c);r.state.view='library';vm.runInContext("showHoverPreview('nimcache')",r.c);r.state.view='architecture';r.dialog.open=true;vm.runInContext("showHoverPreview('nimcache')",r.c);assert.equal(r.state.hovered,null);assert.equal(r.draws(),0);
});
test('Hover and keyboard focus handlers contain no explanation renderer or automatic relationship expansion',()=>{
 const handlers=app.slice(app.indexOf("document.addEventListener('pointerover'"),app.indexOf("document.addEventListener('change'"));assert.ok(!/openModule|showModal|previewPopupRelation|innerHTML|renderInspector/.test(handlers));assert.ok(!app.includes('function previewPopupRelation('));assert.ok(!app.includes('function previewMarkup('));
 const index=fs.readFileSync(new URL('../dist/index.html',import.meta.url),'utf8');assert.ok(!index.includes('id="relation-hover"'));
});
test('Explicit click remains the entry point for complete explanations',()=>{
 const selection=app.slice(app.indexOf('function selectModule('),app.indexOf('function openModule('));assert.ok(selection.includes('openModule(id)'));
 const clicks=app.slice(app.indexOf("document.addEventListener('click'"),app.indexOf("document.addEventListener('pointerover'"));assert.ok(clicks.includes('if(b.dataset.module){selectModule(b.dataset.module)'));assert.ok(clicks.includes('if(b.dataset.relation)'));assert.ok(clicks.includes('renderInspector()'));
});
