import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import vm from 'node:vm';
import {modules,moduleMap,owners,concepts} from '../dist/content.js';
const app=fs.readFileSync(new URL('../dist/app.js',import.meta.url),'utf8');
const state={view:'architecture',selected:'harness',edgeMode:'focus',mapQuery:'',learned:new Set()},root={innerHTML:''};
const esc=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const c=vm.createContext({state,root,modules,moduleMap,owners,concepts,esc,icon:()=>'',moduleIcon:()=>'',drawMap:()=>{},renderInspector:()=>{},applyMapSearch:()=>{},requestAnimationFrame:()=>{}});
vm.runInContext(app.slice(app.indexOf('function node('),app.indexOf('function drawMap(')),c);vm.runInContext('renderArchitecture()',c);
test('The main page renders all five layers and 31 modules without a clipped workspace or overview modal',()=>{
 assert.equal((root.innerHTML.match(/class="node owner-/g)||[]).length,31);for(const m of modules)assert.ok(root.innerHTML.includes(`data-module="${m.id}"`));
 assert.ok(root.innerHTML.includes('class="full-architecture"'));assert.ok(root.innerHTML.includes('id="map-canvas"'));
 for(const removed of ['id="inspector"','id="map-scroll"','id="map-extent"','data-overview-open','独立滚动','class="explore-layout"'])assert.ok(!root.innerHTML.includes(removed),removed);
 const index=fs.readFileSync(new URL('../dist/index.html',import.meta.url),'utf8');assert.ok(!index.includes('architecture-overview'));assert.ok(index.includes('id="module-dialog"'));
});
test('The complete architecture HTML is balanced and does not nest interactive buttons',()=>{
 const stack=[],voids=new Set(['br','input','img','hr','meta','link']);
 for(const t of root.innerHTML.matchAll(/<\/?([a-z][\w-]*)\b[^>]*>/gi)){const tag=t[1].toLowerCase();if(t[0].startsWith('</'))assert.equal(stack.pop(),tag,t[0]);else{if(tag==='button')assert.ok(!stack.includes('button'));if(!voids.has(tag)&&!t[0].endsWith('/>'))stack.push(tag);}}
 assert.deepEqual(stack,[]);
});
test('Every module opens explanations directly and does not reposition the background page',()=>{
 const events=[],state={view:'architecture'};const tab={focus:opts=>events.push(['focus',opts.preventScroll])};
 const c=vm.createContext({state,moduleMap,$:()=>tab,$$:()=>[],history:{replaceState:()=>{}},drawMap:()=>events.push('draw'),openModule:id=>events.push(['open',id])});
 vm.runInContext(app.slice(app.indexOf('function selectModule('),app.indexOf('function openModule(')),c);
 for(const m of modules){events.length=0;vm.runInContext(`selectModule('${m.id}')`,c);assert.ok(events.some(e=>Array.isArray(e)&&e[0]==='open'&&e[1]===m.id));assert.equal(state.detailTab,'relations');assert.ok(events.some(e=>Array.isArray(e)&&e[0]==='focus'&&e[1]===true));}
 const selection=app.slice(app.indexOf('function selectModule('),app.indexOf('function openModule('));assert.ok(!/scrollIntoView|scrollTo|revealSelectedNode|matchMedia/.test(selection));
});
test('Unknown component names cannot open a popup',()=>{
 let opened=false;const c=vm.createContext({moduleMap,openModule:()=>opened=true});vm.runInContext(app.slice(app.indexOf('function selectModule('),app.indexOf('function openModule(')),c);vm.runInContext("selectModule('__proto__');selectModule('not-a-module')",c);assert.equal(opened,false);
});
test('Updating popup knowledge preserves its reading position; changing tabs can reset it',()=>{
 const state={selected:'harness',learned:new Set(['harness'])},progress={textContent:''},body={scrollTop:275};
 const c=vm.createContext({state,modules,moduleMap,moduleDetail:()=>'<div>explanation</div>',$:q=>({'#architecture-progress':progress,'#module-dialog':{open:true},'#dialog-content':{innerHTML:''},'#dialog-content [data-detail-scroll]':body}[q])});
 vm.runInContext(app.slice(app.indexOf('function renderInspector('),app.indexOf('function scrollWithin(')),c);vm.runInContext('renderInspector()',c);assert.equal(body.scrollTop,275);assert.equal(progress.textContent,'已理解 1 / 31');vm.runInContext('renderInspector({resetScroll:true})',c);assert.equal(body.scrollTop,0);
});
