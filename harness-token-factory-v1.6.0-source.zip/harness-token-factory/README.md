# Harness Platform × Token Factory 互动学习网站

中文 AI 软件栈架构互动讲解，版本 **1.6.0**。

- 架构图完整展开；鼠标悬停高亮关联模块与连线。
- 点击组件查看功能、原理、关联用途、边界及参考资料。
- 包含推理与 Agent 模拟、知识库和离线单文件版本。
- 纯静态 HTML/CSS/JavaScript，无后端或运行时第三方依赖。

## 本地运行

需要 Node.js 20.11 或以上版本。

```sh
npm test
npm run preview
```

浏览器打开 http://127.0.0.1:4173 。

## GitHub Pages

仓库 Settings → Pages → Source 选择 **GitHub Actions**。
推送至 `main` 后，工作流先运行内容和交互逻辑检查，再发布 `dist/`。

网站文件位于 `dist/`，独立离线版位于 `offline/`。
更多操作见 [部署说明](README_部署说明.md) 与 [开发说明](README_开发说明.md)。

学习进度只存储于浏览器本地。教学内容仅作技术学习参考。
